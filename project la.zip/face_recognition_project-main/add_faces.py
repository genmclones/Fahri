import face_recognition
import cv2
import os
import pickle

# Buat folder encoding jika belum ada
if not os.path.exists('encodings'):
    os.makedirs('encodings')

name = input("Masukkan nama Anda: ").strip()

# Cek nama tidak kosong
if not name:
    print("⚠️ Nama tidak boleh kosong.")
    exit()

video = cv2.VideoCapture(0)
encodings = []

print("\n📸 Arahkan wajah ke kamera. Tekan 's' untuk simpan, 'q' untuk keluar.\n")

while True:
    ret, frame = video.read()
    if not ret:
        print("⚠️ Tidak bisa mengakses webcam.")
        break

    rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    face_locations = face_recognition.face_locations(rgb_frame)

    # Gambar kotak hijau di wajah
    for (top, right, bottom, left) in face_locations:
        cv2.rectangle(frame, (left, top), (right, bottom), (0, 255, 0), 2)

    cv2.imshow("Webcam - Tambah Wajah", frame)
    key = cv2.waitKey(1)

    if key == ord('s'):
        if face_locations:
            encs = face_recognition.face_encodings(rgb_frame, face_locations)
            if encs:
                encodings.append(encs[0])
                print(f"✅ Wajah ke-{len(encodings)} disimpan.")
            else:
                print("⚠️ Gagal mengambil encoding. Coba ulangi.")
        else:
            print("⚠️ Tidak ada wajah terdeteksi.")
    elif key == ord('q'):
        break

video.release()
cv2.destroyAllWindows()

# Simpan encoding jika ada yang berhasil
if encodings:
    save_path = f'encodings/{name}.pkl'
    with open(save_path, 'wb') as f:
        pickle.dump(encodings, f)
    print(f"\n✅ {len(encodings)} data wajah untuk '{name}' berhasil disimpan di '{save_path}'")
else:
    print("\n⚠️ Tidak ada data wajah yang disimpan.")
