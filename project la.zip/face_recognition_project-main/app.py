from flask import Flask, render_template, request, jsonify
import face_recognition
import cv2
import numpy as np
import os
import pickle
import csv
from datetime import datetime
import base64
from io import BytesIO
from PIL import Image

app = Flask(__name__)

ENCODINGS_DIR = 'encodings'
ATTENDANCE_DIR = 'Attendance'
ATTENDANCE_FILE = os.path.join(ATTENDANCE_DIR, 'attendance.csv')

os.makedirs(ENCODINGS_DIR, exist_ok=True)
os.makedirs(ATTENDANCE_DIR, exist_ok=True)

# Load known faces dari folder encoding
def load_known_faces():
    known_encodings = []
    known_names = []
    for filename in os.listdir(ENCODINGS_DIR):
        if filename.endswith('.pkl'):
            name = os.path.splitext(filename)[0]
            with open(os.path.join(ENCODINGS_DIR, filename), 'rb') as f:
                encs = pickle.load(f)
                for enc in encs:
                    known_encodings.append(enc)
                    known_names.append(name)
    return known_encodings, known_names

# Simpan kehadiran (tanpa batas 1x per hari)
def mark_attendance(name):
    now = datetime.now()
    date_str = now.strftime('%Y-%m-%d')
    time_str = now.strftime('%H:%M:%S')
    with open(ATTENDANCE_FILE, mode='a', newline='') as f:
        writer = csv.writer(f)
        writer.writerow([name, date_str, time_str])

# Beranda
@app.route('/')
def index():
    return render_template('index.html')

# Proses pengenalan wajah dan absensi
@app.route('/absen', methods=['POST'])
def absen():
    data_url = request.form['image']
    img_data = base64.b64decode(data_url.split(',')[1])
    img = Image.open(BytesIO(img_data)).convert('RGB')
    img_np = np.array(img)

    rgb_frame = cv2.cvtColor(img_np, cv2.COLOR_RGB2BGR)
    face_locations = face_recognition.face_locations(rgb_frame)
    face_encodings = face_recognition.face_encodings(rgb_frame, face_locations)

    known_encodings, known_names = load_known_faces()

    for face_encoding in face_encodings:
        matches = face_recognition.compare_faces(known_encodings, face_encoding, tolerance=0.45)
        face_distances = face_recognition.face_distance(known_encodings, face_encoding)
        if len(face_distances) > 0:
            best_match = np.argmin(face_distances)
            if matches[best_match]:
                name = known_names[best_match]
                mark_attendance(name)
                return jsonify({'status': 'success', 'name': name})
    
    return jsonify({'status': 'fail', 'message': 'Wajah tidak dikenali'})

# Tampilkan riwayat
@app.route('/riwayat')
def riwayat():
    data = []
    if os.path.exists(ATTENDANCE_FILE):
        with open(ATTENDANCE_FILE, newline='') as f:
            reader = csv.reader(f)
            next(reader, None)
            data = list(reader)
    return render_template('attendance.html', data=data)

if __name__ == '__main__':
    app.run(debug=True)
