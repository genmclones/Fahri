const video = document.getElementById("video");

navigator.mediaDevices.getUserMedia({ video: true })
  .then(stream => { video.srcObject = stream; })
  .catch(err => { alert("Webcam gagal: " + err.message); });

function ambilAbsen() {
  const canvas = document.createElement('canvas');
  canvas.width = video.videoWidth;
  canvas.height = video.videoHeight;
  canvas.getContext('2d').drawImage(video, 0, 0);

  const imgData = canvas.toDataURL('image/jpeg');

  fetch('/absen', {
    method: 'POST',
    body: new URLSearchParams({ image: imgData }),
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
  })
  .then(res => res.json())
  .then(data => {
    if (data.status === "success") {
      alert("✅ Absen berhasil: " + data.name);
    } else {
      alert("❌ " + data.message);
    }
  });
}
