import face_recognition
import cv2
import os
import pickle
import csv
from datetime import datetime

# ======= Load Background =======
imgBackground = cv2.imread("background.png")

# ======= Load Encodings =======
known_encodings = []
known_names = []

for filename in os.listdir('encodings'):
    if filename.endswith('.pkl'):
        name = os.path.splitext(filename)[0]
        with open(f'encodings/{filename}', 'rb') as f:
            encodings = pickle.load(f)
            for enc in encodings:
                known_encodings.append(enc)
                known_names.append(name)

# ======= Setup Attendance File =======
attendance_dir = 'Attendance'
attendance_file = os.path.join(attendance_dir, 'attendance.csv')
if not os.path.exists(attendance_dir):
    os.makedirs(attendance_dir)

if not os.path.exists(attendance_file):
    with open(attendance_file, mode='w', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(['Name', 'Date', 'Time'])

def mark_attendance(name):
    now = datetime.now()
    date_str = now.strftime('%Y-%m-%d')
    time_str = now.strftime('%H:%M:%S')
    with open(attendance_file, mode='a', newline='') as file:
        writer = csv.writer(file)
        writer.writerow([name, date_str, time_str])
    print(f"✅ {name} dicatat pada {date_str} {time_str}")

# ======= Start Webcam =======
video = cv2.VideoCapture(0)
print("Tekan 'o' untuk mencatat kehadiran. Tekan 'q' untuk keluar.")

current_name = "Unknown"

while True:
    ret, frame = video.read()
    rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    face_locations = face_recognition.face_locations(rgb_frame)
    face_encodings = face_recognition.face_encodings(rgb_frame, face_locations)

    found_name = "Unknown"
    for (top, right, bottom, left), face_encoding in zip(face_locations, face_encodings):
        matches = face_recognition.compare_faces(known_encodings, face_encoding, tolerance=0.45)
        face_distances = face_recognition.face_distance(known_encodings, face_encoding)
        if face_distances.size > 0:
            best_match_index = face_distances.argmin()
            if matches[best_match_index]:
                found_name = known_names[best_match_index]

        cv2.rectangle(frame, (left, top), (right, bottom), (0, 255, 0), 2)
        cv2.putText(frame, found_name, (left, top - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 255, 0), 2)

    current_name = found_name

    # ======= Masukkan webcam ke background =======
    if imgBackground is not None:
        imgBackground[162:162 + 480, 55:55 + 640] = frame
        cv2.imshow("Face Recognition Attendance", imgBackground)
    else:
        cv2.imshow("Face Recognition Attendance", frame)

    key = cv2.waitKey(1) & 0xFF
    if key == ord('o'):
        if current_name != "Unknown":
            mark_attendance(current_name)
        else:
            print("⚠️ Wajah tidak dikenal.")
    elif key == ord('q'):
        break

video.release()
cv2.destroyAllWindows()
